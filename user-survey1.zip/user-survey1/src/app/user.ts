export class User{
    constructor(
        firstName:string,
        lastName:string,
        emailId:string,
        mobile:number,
        password:string

    ){}
}