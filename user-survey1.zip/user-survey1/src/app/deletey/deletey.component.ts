import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deletey',
  templateUrl: './deletey.component.html',
  styleUrls: ['./deletey.component.css']
})
export class DeleteyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
