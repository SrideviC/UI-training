import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteyComponent } from './deletey.component';

describe('DeleteyComponent', () => {
  let component: DeleteyComponent;
  let fixture: ComponentFixture<DeleteyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
