export class Survey1{
    constructor(
        title:string,
        description:string,
        city:string,
        state:string,
        country:string,
        zip:number,
        surveyDate:number

    ){}
}